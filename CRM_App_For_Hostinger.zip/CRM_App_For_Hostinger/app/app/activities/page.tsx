'use client';

import { useEffect, useState } from 'react';
import { supabase, Activity } from '@/lib/supabase/client';
import { useAuth } from '@/lib/auth/auth-context';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Plus, CheckSquare, Calendar, Edit, Trash2, Check } from 'lucide-react';
import { format } from 'date-fns';
import { useToast } from '@/hooks/use-toast';

export default function ActivitiesPage() {
  const [activities, setActivities] = useState<Activity[]>([]);
  const [loading, setLoading] = useState(true);
  const [showDialog, setShowDialog] = useState(false);
  const [editingActivity, setEditingActivity] = useState<Activity | null>(null);
  const [activityType, setActivityType] = useState<'TASK' | 'EVENT'>('TASK');
  const { user } = useAuth();
  const { toast } = useToast();

  const [leads, setLeads] = useState<Array<{ id: string; company_name: string }>>([]);
  const [accounts, setAccounts] = useState<Array<{ id: string; name: string }>>([]);
  const [contacts, setContacts] = useState<Array<{ id: string; first_name: string; last_name: string }>>([]);
  const [opportunities, setOpportunities] = useState<Array<{ id: string; name: string }>>([]);

  const [formData, setFormData] = useState({
    subject: '',
    description: '',
    status: 'NOT_STARTED',
    priority: 'MEDIUM',
    due_date: '',
    start_time: '',
    end_time: '',
    location: '',
    related_to_type: '',
    related_to_id: '',
  });

  const fetchActivities = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('activities')
      .select('*, owner:profiles!activities_owner_id_fkey(*)')
      .eq('owner_id', user?.id)
      .order('created_at', { ascending: false });

    if (data) setActivities(data);
    setLoading(false);
  };

  const fetchEntities = async () => {
    const [leadsRes, accountsRes, contactsRes, oppsRes] = await Promise.all([
      supabase.from('leads').select('id, company_name').order('company_name').limit(100),
      supabase.from('accounts').select('id, name').order('name').limit(100),
      supabase.from('contacts').select('id, first_name, last_name').order('first_name').limit(100),
      supabase.from('opportunities').select('id, name').order('name').limit(100),
    ]);

    if (leadsRes.data) setLeads(leadsRes.data);
    if (accountsRes.data) setAccounts(accountsRes.data);
    if (contactsRes.data) setContacts(contactsRes.data);
    if (oppsRes.data) setOpportunities(oppsRes.data);
  };

  useEffect(() => {
    if (user) {
      fetchActivities();
      fetchEntities();
    }
  }, [user]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const activityData: any = {
      type: activityType,
      subject: formData.subject,
      description: formData.description,
      related_to_type: formData.related_to_type || null,
      related_to_id: formData.related_to_id || null,
    };

    if (activityType === 'TASK') {
      activityData.status = formData.status;
      activityData.priority = formData.priority;
      activityData.due_date = formData.due_date || null;
      activityData.completed = formData.status === 'COMPLETED';
    } else {
      activityData.start_time = formData.start_time || null;
      activityData.end_time = formData.end_time || null;
      activityData.location = formData.location || null;
    }

    if (editingActivity) {
      const { error } = await supabase
        .from('activities')
        .update(activityData)
        .eq('id', editingActivity.id);

      if (!error) {
        toast({
          title: 'Activity updated',
          description: 'Activity has been updated successfully',
        });
      }
    } else {
      activityData.owner_id = user?.id;
      activityData.assigned_to = user?.id;

      const { error } = await supabase.from('activities').insert(activityData);

      if (!error) {
        toast({
          title: 'Activity created',
          description: 'Activity has been created successfully',
        });
      }
    }

    setShowDialog(false);
    setEditingActivity(null);
    setFormData({
      subject: '',
      description: '',
      status: 'NOT_STARTED',
      priority: 'MEDIUM',
      due_date: '',
      start_time: '',
      end_time: '',
      location: '',
      related_to_type: '',
      related_to_id: '',
    });
    fetchActivities();
  };

  const handleEdit = (activity: Activity) => {
    setEditingActivity(activity);
    setActivityType(activity.type === 'TASK' || activity.type === 'EVENT' ? activity.type : 'TASK');

    setFormData({
      subject: activity.subject || '',
      description: activity.description || '',
      status: activity.status || 'NOT_STARTED',
      priority: activity.priority || 'MEDIUM',
      due_date: activity.due_date ? new Date(activity.due_date).toISOString().slice(0, 16) : '',
      start_time: activity.start_time ? new Date(activity.start_time).toISOString().slice(0, 16) : '',
      end_time: activity.end_time ? new Date(activity.end_time).toISOString().slice(0, 16) : '',
      location: activity.location || '',
      related_to_type: activity.related_to_type || '',
      related_to_id: activity.related_to_id || '',
    });
    setShowDialog(true);
  };

  const handleDelete = async (activityId: string) => {
    if (!confirm('Are you sure you want to delete this activity?')) return;

    const { error } = await supabase
      .from('activities')
      .delete()
      .eq('id', activityId);

    if (!error) {
      toast({
        title: 'Activity deleted',
        description: 'Activity has been deleted successfully',
      });
      fetchActivities();
    }
  };

  const handleMarkComplete = async (activityId: string) => {
    const { error } = await supabase
      .from('activities')
      .update({ completed: true, status: 'COMPLETED' })
      .eq('id', activityId);

    if (!error) {
      toast({
        title: 'Task completed',
        description: 'Task has been marked as completed',
      });
      fetchActivities();
    }
  };

  const handleDialogClose = (open: boolean) => {
    setShowDialog(open);
    if (!open) {
      setEditingActivity(null);
      setFormData({
        subject: '',
        description: '',
        status: 'NOT_STARTED',
        priority: 'MEDIUM',
        due_date: '',
        start_time: '',
        end_time: '',
        location: '',
        related_to_type: '',
        related_to_id: '',
      });
    }
  };

  const getRelatedEntityName = (activity: Activity) => {
    if (!activity.related_to_type || !activity.related_to_id) return null;

    switch (activity.related_to_type) {
      case 'LEAD':
        const lead = leads.find((l) => l.id === activity.related_to_id);
        return lead ? `Lead: ${lead.company_name}` : 'Lead';
      case 'ACCOUNT':
        const account = accounts.find((a) => a.id === activity.related_to_id);
        return account ? `Account: ${account.name}` : 'Account';
      case 'CONTACT':
        const contact = contacts.find((c) => c.id === activity.related_to_id);
        return contact ? `Contact: ${contact.first_name} ${contact.last_name}` : 'Contact';
      case 'OPPORTUNITY':
        const opp = opportunities.find((o) => o.id === activity.related_to_id);
        return opp ? `Opportunity: ${opp.name}` : 'Opportunity';
      default:
        return null;
    }
  };

  const tasks = activities.filter((a) => a.type === 'TASK');
  const events = activities.filter((a) => a.type === 'EVENT');

  if (loading) {
    return <div className="p-6">Loading...</div>;
  }

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Activities</h1>
          <p className="text-gray-600 mt-1">Manage your tasks and events</p>
        </div>
        <Dialog open={showDialog} onOpenChange={handleDialogClose}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              New Activity
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingActivity ? 'Edit Activity' : 'Create Activity'}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label>Type</Label>
                <Select
                  value={activityType}
                  onValueChange={(value: any) => setActivityType(value)}
                  disabled={!!editingActivity}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="TASK">Task</SelectItem>
                    <SelectItem value="EVENT">Event</SelectItem>
                  </SelectContent>
                </Select>
                {editingActivity && (
                  <p className="text-xs text-gray-500">Type cannot be changed when editing</p>
                )}
              </div>

              <div className="space-y-2">
                <Label>Subject</Label>
                <Input
                  value={formData.subject}
                  onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label>Description</Label>
                <Textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label>Related To (Optional)</Label>
                <div className="flex items-center space-x-2">
                  <Select
                    value={formData.related_to_type || undefined}
                    onValueChange={(value) => setFormData({ ...formData, related_to_type: value, related_to_id: '' })}
                  >
                    <SelectTrigger className="flex-1">
                      <SelectValue placeholder="Select type (optional)" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="LEAD">Lead</SelectItem>
                      <SelectItem value="ACCOUNT">Account</SelectItem>
                      <SelectItem value="CONTACT">Contact</SelectItem>
                      <SelectItem value="OPPORTUNITY">Opportunity</SelectItem>
                    </SelectContent>
                  </Select>
                  {formData.related_to_type && (
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => setFormData({ ...formData, related_to_type: '', related_to_id: '' })}
                    >
                      Clear
                    </Button>
                  )}
                </div>
              </div>

              {formData.related_to_type && (
                <div className="space-y-2">
                  <Label>Select {formData.related_to_type}</Label>
                  <Select
                    value={formData.related_to_id}
                    onValueChange={(value) => setFormData({ ...formData, related_to_id: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select..." />
                    </SelectTrigger>
                    <SelectContent>
                      {formData.related_to_type === 'LEAD' &&
                        leads.map((lead) => (
                          <SelectItem key={lead.id} value={lead.id}>
                            {lead.company_name}
                          </SelectItem>
                        ))}
                      {formData.related_to_type === 'ACCOUNT' &&
                        accounts.map((account) => (
                          <SelectItem key={account.id} value={account.id}>
                            {account.name}
                          </SelectItem>
                        ))}
                      {formData.related_to_type === 'CONTACT' &&
                        contacts.map((contact) => (
                          <SelectItem key={contact.id} value={contact.id}>
                            {contact.first_name} {contact.last_name}
                          </SelectItem>
                        ))}
                      {formData.related_to_type === 'OPPORTUNITY' &&
                        opportunities.map((opp) => (
                          <SelectItem key={opp.id} value={opp.id}>
                            {opp.name}
                          </SelectItem>
                        ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {activityType === 'TASK' ? (
                <>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Status</Label>
                      <Select
                        value={formData.status}
                        onValueChange={(value) => setFormData({ ...formData, status: value })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="NOT_STARTED">Not Started</SelectItem>
                          <SelectItem value="IN_PROGRESS">In Progress</SelectItem>
                          <SelectItem value="COMPLETED">Completed</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>Priority</Label>
                      <Select
                        value={formData.priority}
                        onValueChange={(value) => setFormData({ ...formData, priority: value })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="LOW">Low</SelectItem>
                          <SelectItem value="MEDIUM">Medium</SelectItem>
                          <SelectItem value="HIGH">High</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Due Date</Label>
                    <Input
                      type="datetime-local"
                      value={formData.due_date}
                      onChange={(e) => setFormData({ ...formData, due_date: e.target.value })}
                    />
                  </div>
                </>
              ) : (
                <>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Start Time</Label>
                      <Input
                        type="datetime-local"
                        value={formData.start_time}
                        onChange={(e) => setFormData({ ...formData, start_time: e.target.value })}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>End Time</Label>
                      <Input
                        type="datetime-local"
                        value={formData.end_time}
                        onChange={(e) => setFormData({ ...formData, end_time: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Location</Label>
                    <Input
                      value={formData.location}
                      onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                      placeholder="e.g., Conference Room A, Zoom"
                    />
                  </div>
                </>
              )}

              <div className="flex justify-end space-x-3 pt-4">
                <Button type="button" variant="outline" onClick={() => handleDialogClose(false)}>
                  Cancel
                </Button>
                <Button type="submit">
                  {editingActivity ? 'Update Activity' : 'Create Activity'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="tasks">
        <TabsList>
          <TabsTrigger value="tasks">
            <CheckSquare className="h-4 w-4 mr-2" />
            Tasks ({tasks.length})
          </TabsTrigger>
          <TabsTrigger value="events">
            <Calendar className="h-4 w-4 mr-2" />
            Events ({events.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="tasks" className="mt-6">
          <div className="space-y-3">
            {tasks.length === 0 ? (
              <Card>
                <CardContent className="p-8 text-center text-gray-500">
                  No tasks found. Create your first task to get started.
                </CardContent>
              </Card>
            ) : (
              tasks.map((task) => (
                <Card key={task.id}>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="font-medium text-gray-900">{task.subject}</h3>
                        {task.description && (
                          <p className="text-sm text-gray-600 mt-1">{task.description}</p>
                        )}
                        {getRelatedEntityName(task) && (
                          <p className="text-xs text-blue-600 mt-1">
                            {getRelatedEntityName(task)}
                          </p>
                        )}
                        <div className="flex items-center space-x-3 mt-2">
                          <Badge variant="outline">{task.status?.replace('_', ' ')}</Badge>
                          <Badge variant="secondary">{task.priority}</Badge>
                          {task.due_date && (
                            <span className="text-xs text-gray-500">
                              Due: {format(new Date(task.due_date), 'MMM d, yyyy h:mm a')}
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-2 ml-4">
                        {!task.completed && (
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleMarkComplete(task.id)}
                            title="Mark as complete"
                          >
                            <Check className="h-4 w-4 text-green-600" />
                          </Button>
                        )}
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleEdit(task)}
                          title="Edit"
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleDelete(task.id)}
                          title="Delete"
                        >
                          <Trash2 className="h-4 w-4 text-red-600" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>

        <TabsContent value="events" className="mt-6">
          <div className="space-y-3">
            {events.length === 0 ? (
              <Card>
                <CardContent className="p-8 text-center text-gray-500">
                  No events found. Create your first event to get started.
                </CardContent>
              </Card>
            ) : (
              events.map((event) => (
                <Card key={event.id}>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="font-medium text-gray-900">{event.subject}</h3>
                        {event.description && (
                          <p className="text-sm text-gray-600 mt-1">{event.description}</p>
                        )}
                        {getRelatedEntityName(event) && (
                          <p className="text-xs text-blue-600 mt-1">
                            {getRelatedEntityName(event)}
                          </p>
                        )}
                        <div className="flex items-center space-x-4 mt-2 text-sm text-gray-600">
                          {event.start_time && (
                            <span>Start: {format(new Date(event.start_time), 'MMM d, yyyy h:mm a')}</span>
                          )}
                          {event.location && <span>Location: {event.location}</span>}
                        </div>
                      </div>
                      <div className="flex items-center gap-2 ml-4">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleEdit(event)}
                          title="Edit"
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleDelete(event.id)}
                          title="Delete"
                        >
                          <Trash2 className="h-4 w-4 text-red-600" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
