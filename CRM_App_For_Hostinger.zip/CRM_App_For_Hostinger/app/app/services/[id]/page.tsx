'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { supabase, ServiceContract, ServiceLog, Profile } from '@/lib/supabase/client';
import { useAuth } from '@/lib/auth/auth-context';
import { RecordTabs } from '@/components/shared/record-tabs';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Calendar, MapPin, User, DollarSign, Check, FileText } from 'lucide-react';
import { format, parseISO, addMonths, addYears, isPast, differenceInDays } from 'date-fns';
import { useToast } from '@/hooks/use-toast';
import Link from 'next/link';

export default function ServiceDetailPage() {
  const params = useParams();
  const router = useRouter();
  const serviceId = params.id as string;
  const { user } = useAuth();
  const { toast } = useToast();

  const [service, setService] = useState<ServiceContract | null>(null);
  const [serviceLogs, setServiceLogs] = useState<ServiceLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCompleteDialog, setShowCompleteDialog] = useState(false);

  const [completeFormData, setCompleteFormData] = useState({
    performed_at: new Date().toISOString().slice(0, 16),
    note: '',
    price_charged: '',
  });

  const fetchService = async () => {
    const { data } = await supabase
      .from('service_contracts')
      .select('*, account:accounts(*), assigned_to:profiles!service_contracts_assigned_to_id_fkey(*)')
      .eq('id', serviceId)
      .single();

    if (data) setService(data);
  };

  const fetchServiceLogs = async () => {
    const { data } = await supabase
      .from('service_logs')
      .select('*, performed_by:profiles!service_logs_performed_by_id_fkey(*)')
      .eq('service_id', serviceId)
      .order('performed_at', { ascending: false });

    if (data) setServiceLogs(data);
  };

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      await Promise.all([fetchService(), fetchServiceLogs()]);
      setLoading(false);
    };

    if (serviceId) {
      loadData();
    }
  }, [serviceId]);

  const handleCompleteService = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!service) return;

    const performedAt = completeFormData.performed_at;
    const nextServiceDueAt = service.interval_unit === 'MONTHS'
      ? addMonths(parseISO(performedAt), service.interval_value)
      : addYears(parseISO(performedAt), service.interval_value);

    const { error: logError } = await supabase.from('service_logs').insert({
      service_id: serviceId,
      performed_at: performedAt,
      performed_by_id: user?.id,
      note: completeFormData.note || null,
      price_charged: completeFormData.price_charged ? parseFloat(completeFormData.price_charged) : null,
    });

    if (logError) {
      toast({
        title: 'Error',
        description: 'Failed to create service log',
        variant: 'destructive',
      });
      return;
    }

    const { error: updateError } = await supabase
      .from('service_contracts')
      .update({
        last_service_at: performedAt,
        next_service_due_at: nextServiceDueAt.toISOString(),
      })
      .eq('id', serviceId);

    if (!updateError) {
      toast({
        title: 'Service completed',
        description: 'Service has been marked as completed and next service date updated',
      });
      setShowCompleteDialog(false);
      setCompleteFormData({
        performed_at: new Date().toISOString().slice(0, 16),
        note: '',
        price_charged: '',
      });
      fetchService();
      fetchServiceLogs();
    }
  };

  const getServiceStatus = () => {
    if (!service) return 'active';
    if (service.status !== 'ACTIVE') return service.status.toLowerCase();
    const dueDate = parseISO(service.next_service_due_at);
    const now = new Date();
    const daysUntilDue = differenceInDays(dueDate, now);

    if (isPast(dueDate)) return 'overdue';
    if (daysUntilDue <= 7) return 'due-soon';
    return 'active';
  };

  const getStatusBadge = () => {
    const status = getServiceStatus();
    switch (status) {
      case 'overdue':
        return <Badge variant="destructive">Overdue</Badge>;
      case 'due-soon':
        return <Badge className="bg-orange-500 text-white">Due Soon</Badge>;
      case 'paused':
        return <Badge variant="secondary">Paused</Badge>;
      case 'closed':
        return <Badge variant="outline">Closed</Badge>;
      default:
        return <Badge className="bg-green-600 text-white">Active</Badge>;
    }
  };

  if (loading || !service) {
    return <div className="p-6">Loading...</div>;
  }

  const tabs = [
    {
      value: 'details',
      label: 'Details',
      content: (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Service Information</span>
                {service.status === 'ACTIVE' && (
                  <Dialog open={showCompleteDialog} onOpenChange={setShowCompleteDialog}>
                    <DialogTrigger asChild>
                      <Button>
                        <Check className="h-4 w-4 mr-2" />
                        Mark Service Done
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Complete Service</DialogTitle>
                      </DialogHeader>
                      <form onSubmit={handleCompleteService} className="space-y-4">
                        <div className="space-y-2">
                          <Label>Performed At</Label>
                          <Input
                            type="datetime-local"
                            value={completeFormData.performed_at}
                            onChange={(e) => setCompleteFormData({ ...completeFormData, performed_at: e.target.value })}
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Notes</Label>
                          <Textarea
                            value={completeFormData.note}
                            onChange={(e) => setCompleteFormData({ ...completeFormData, note: e.target.value })}
                            placeholder="What was done, any remarks..."
                            rows={3}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Price Charged (Optional)</Label>
                          <Input
                            type="number"
                            step="0.01"
                            min="0"
                            value={completeFormData.price_charged}
                            onChange={(e) => setCompleteFormData({ ...completeFormData, price_charged: e.target.value })}
                            placeholder="0.00"
                          />
                        </div>
                        <div className="flex justify-end space-x-3 pt-4">
                          <Button type="button" variant="outline" onClick={() => setShowCompleteDialog(false)}>
                            Cancel
                          </Button>
                          <Button type="submit">Complete Service</Button>
                        </div>
                      </form>
                    </DialogContent>
                  </Dialog>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <Label className="text-gray-500">Account</Label>
                  <Link href={`/app/accounts/${service.account_id}`} className="hover:text-blue-600">
                    <p className="font-medium mt-1">{service.account?.name}</p>
                  </Link>
                </div>
                <div>
                  <Label className="text-gray-500">Status</Label>
                  <div className="mt-1">{getStatusBadge()}</div>
                </div>
                <div>
                  <Label className="text-gray-500">Device Type</Label>
                  <p className="font-medium mt-1">{service.device_type}</p>
                </div>
                {service.device_serial && (
                  <div>
                    <Label className="text-gray-500">Serial Number</Label>
                    <p className="font-medium mt-1">{service.device_serial}</p>
                  </div>
                )}
                <div>
                  <Label className="text-gray-500">Last Service</Label>
                  <p className="font-medium mt-1">
                    {format(parseISO(service.last_service_at), 'MMM d, yyyy h:mm a')}
                  </p>
                </div>
                <div>
                  <Label className="text-gray-500">Next Service Due</Label>
                  <p className="font-medium mt-1">
                    {format(parseISO(service.next_service_due_at), 'MMM d, yyyy')}
                  </p>
                </div>
                <div>
                  <Label className="text-gray-500">Service Interval</Label>
                  <p className="font-medium mt-1">
                    {service.interval_value} {service.interval_unit.toLowerCase()}
                  </p>
                </div>
                {service.service_price && (
                  <div>
                    <Label className="text-gray-500">Service Price</Label>
                    <p className="font-medium mt-1">
                      {service.service_price.toFixed(2)} {service.currency}
                    </p>
                  </div>
                )}
                {service.assigned_to && (
                  <div>
                    <Label className="text-gray-500">Assigned To</Label>
                    <p className="font-medium mt-1">{service.assigned_to.full_name}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Location & Contact</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-gray-500 flex items-center">
                  <MapPin className="h-4 w-4 mr-1" />
                  Address
                </Label>
                <p className="font-medium mt-1">{service.location_address}</p>
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label className="text-gray-500 flex items-center">
                    <User className="h-4 w-4 mr-1" />
                    Contact Person
                  </Label>
                  <p className="font-medium mt-1">{service.contact_name}</p>
                </div>
                {service.contact_phone && (
                  <div>
                    <Label className="text-gray-500">Phone</Label>
                    <p className="font-medium mt-1">{service.contact_phone}</p>
                  </div>
                )}
                {service.contact_email && (
                  <div>
                    <Label className="text-gray-500">Email</Label>
                    <p className="font-medium mt-1">{service.contact_email}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {service.notes && (
            <Card>
              <CardHeader>
                <CardTitle>Notes</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 whitespace-pre-wrap">{service.notes}</p>
              </CardContent>
            </Card>
          )}
        </div>
      ),
    },
    {
      value: 'history',
      label: 'Service History',
      content: (
        <div className="space-y-4">
          {serviceLogs.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center text-gray-500">
                No service history yet. Mark the first service as done to create history.
              </CardContent>
            </Card>
          ) : (
            serviceLogs.map((log) => (
              <Card key={log.id}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3">
                        <Calendar className="h-4 w-4 text-gray-500" />
                        <span className="font-medium">
                          {format(parseISO(log.performed_at), 'MMM d, yyyy h:mm a')}
                        </span>
                        {log.performed_by && (
                          <span className="text-sm text-gray-600">
                            by {log.performed_by.full_name}
                          </span>
                        )}
                      </div>
                      {log.note && (
                        <p className="text-gray-700 mt-2 ml-7">{log.note}</p>
                      )}
                      {log.price_charged && (
                        <div className="flex items-center mt-2 ml-7 text-sm text-gray-600">
                          <DollarSign className="h-3 w-3 mr-1" />
                          <span>Charged: {log.price_charged.toFixed(2)} {service.currency}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      ),
    },
    {
      value: 'documents',
      label: 'Documents',
      content: (
        <Card>
          <CardContent className="p-8 text-center text-gray-500">
            <FileText className="h-12 w-12 mx-auto mb-3 text-gray-400" />
            <p>Document management for services coming soon</p>
          </CardContent>
        </Card>
      ),
    },
  ];

  return (
    <div className="p-6">
      <div className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <Link href="/app/services" className="text-sm text-blue-600 hover:text-blue-800 mb-2 inline-block">
              ← Back to Services
            </Link>
            <div className="flex items-center space-x-3">
              <h1 className="text-2xl font-bold text-gray-900">{service.device_type}</h1>
              {getStatusBadge()}
            </div>
            <p className="text-gray-600 mt-1">Service Contract for {service.account?.name}</p>
          </div>
        </div>
      </div>
      <RecordTabs tabs={tabs} />
    </div>
  );
}
