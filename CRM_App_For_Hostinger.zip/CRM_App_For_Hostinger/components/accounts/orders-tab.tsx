'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase/client';
import { useAuth } from '@/lib/auth/auth-context';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Plus, Upload, Download, File, Edit } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Order {
  id: string;
  order_number: string;
  ordered_at: string;
  status: string;
  amount: number;
  paid_amount: number;
  currency: string;
  due_date: string;
  notes: string;
  created_at: string;
}

interface OrdersTabProps {
  accountId: string;
}

const statusColors: Record<string, string> = {
  PENDING: 'bg-yellow-100 text-yellow-800',
  PAID: 'bg-green-100 text-green-800',
  PARTIALLY_PAID: 'bg-blue-100 text-blue-800',
  OVERDUE: 'bg-red-100 text-red-800',
  CANCELLED: 'bg-gray-100 text-gray-800',
};

export function OrdersTab({ accountId }: OrdersTabProps) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [showOrderDialog, setShowOrderDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [editingOrder, setEditingOrder] = useState<Order | null>(null);
  const [formData, setFormData] = useState({
    order_number: '',
    ordered_at: new Date().toISOString().split('T')[0],
    status: 'PENDING',
    amount: '',
    paid_amount: '0',
    currency: 'USD',
    due_date: '',
    notes: '',
  });
  const [totalPaid, setTotalPaid] = useState(0);
  const [totalOutstanding, setTotalOutstanding] = useState(0);
  const { user } = useAuth();
  const { toast } = useToast();

  const fetchOrders = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('orders')
      .select('*')
      .eq('account_id', accountId)
      .order('ordered_at', { ascending: false });

    if (data) {
      setOrders(data);

      const paid = data.reduce((sum, order) => sum + (Number(order.paid_amount) || 0), 0);
      const outstanding = data.reduce((sum, order) => {
        const amount = Number(order.amount) || 0;
        const paidAmount = Number(order.paid_amount) || 0;
        return sum + (amount - paidAmount);
      }, 0);

      setTotalPaid(paid);
      setTotalOutstanding(outstanding);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchOrders();
  }, [accountId]);

  const handleEditOrder = (order: Order) => {
    setEditingOrder(order);
    setFormData({
      order_number: order.order_number,
      ordered_at: order.ordered_at.split('T')[0],
      status: order.status,
      amount: order.amount.toString(),
      paid_amount: order.paid_amount.toString(),
      currency: order.currency,
      due_date: order.due_date ? order.due_date.split('T')[0] : '',
      notes: order.notes || '',
    });
    setShowEditDialog(true);
  };

  const handleUpdateOrder = async () => {
    if (!editingOrder || !formData.order_number || !formData.amount) {
      toast({
        title: 'Missing required fields',
        description: 'Order number and amount are required',
        variant: 'destructive',
      });
      return;
    }

    try {
      const paidAmount = parseFloat(formData.paid_amount);
      const totalAmount = parseFloat(formData.amount);

      let status = formData.status;
      if (paidAmount >= totalAmount) {
        status = 'PAID';
      } else if (paidAmount > 0 && paidAmount < totalAmount) {
        status = 'PARTIALLY_PAID';
      }

      const { error } = await supabase
        .from('orders')
        .update({
          order_number: formData.order_number,
          ordered_at: formData.ordered_at,
          status: status,
          amount: totalAmount,
          paid_amount: paidAmount,
          currency: formData.currency,
          due_date: formData.due_date || null,
          notes: formData.notes || null,
        })
        .eq('id', editingOrder.id);

      if (error) throw error;

      toast({
        title: 'Order updated',
        description: 'Order has been updated successfully',
      });

      setShowEditDialog(false);
      setEditingOrder(null);
      setFormData({
        order_number: '',
        ordered_at: new Date().toISOString().split('T')[0],
        status: 'PENDING',
        amount: '',
        paid_amount: '0',
        currency: 'USD',
        due_date: '',
        notes: '',
      });
      fetchOrders();
    } catch (error: any) {
      toast({
        title: 'Failed to update order',
        description: error.message,
        variant: 'destructive',
      });
    }
  };

  const handleCreateOrder = async () => {
    if (!formData.order_number || !formData.amount) {
      toast({
        title: 'Missing required fields',
        description: 'Order number and amount are required',
        variant: 'destructive',
      });
      return;
    }

    try {
      const { error } = await supabase.from('orders').insert({
        account_id: accountId,
        order_number: formData.order_number,
        ordered_at: formData.ordered_at,
        status: formData.status,
        amount: parseFloat(formData.amount),
        paid_amount: parseFloat(formData.paid_amount),
        currency: formData.currency,
        due_date: formData.due_date || null,
        notes: formData.notes || null,
        created_by: user?.id,
      });

      if (error) throw error;

      toast({
        title: 'Order created',
        description: 'Order has been created successfully',
      });

      setShowOrderDialog(false);
      setFormData({
        order_number: '',
        ordered_at: new Date().toISOString().split('T')[0],
        status: 'PENDING',
        amount: '',
        paid_amount: '0',
        currency: 'USD',
        due_date: '',
        notes: '',
      });
      fetchOrders();
    } catch (error: any) {
      toast({
        title: 'Failed to create order',
        description: error.message,
        variant: 'destructive',
      });
    }
  };

  const isOverdue = (order: Order) => {
    if (!order.due_date || order.status === 'PAID' || order.status === 'CANCELLED') {
      return false;
    }
    const amount = Number(order.amount) || 0;
    const paidAmount = Number(order.paid_amount) || 0;
    return new Date(order.due_date) < new Date() && amount > paidAmount;
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="text-sm text-gray-600">Total Paid</div>
            <div className="text-3xl font-bold text-green-600 mt-2">
              ${totalPaid.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="text-sm text-gray-600">Total Outstanding</div>
            <div className="text-3xl font-bold text-red-600 mt-2">
              ${totalOutstanding.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium">Orders & Invoices</h3>
            <Button size="sm" onClick={() => setShowOrderDialog(true)}>
              <Plus className="h-4 w-4 mr-1" />
              New Order
            </Button>
          </div>

          {loading ? (
            <p className="text-center py-4 text-gray-500">Loading orders...</p>
          ) : orders.length === 0 ? (
            <p className="text-gray-500 text-center py-4">No orders yet</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Order #</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Paid</TableHead>
                  <TableHead>Outstanding</TableHead>
                  <TableHead>Due Date</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {orders.map((order) => {
                  const outstanding = Number(order.amount) - Number(order.paid_amount);
                  const overdue = isOverdue(order);

                  return (
                    <TableRow key={order.id} className={overdue ? 'bg-red-50' : ''}>
                      <TableCell className="font-medium">{order.order_number}</TableCell>
                      <TableCell>{new Date(order.ordered_at).toLocaleDateString()}</TableCell>
                      <TableCell>
                        <Badge className={statusColors[order.status] || statusColors.PENDING}>
                          {order.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {order.currency} {Number(order.amount).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </TableCell>
                      <TableCell>
                        {order.currency} {Number(order.paid_amount).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </TableCell>
                      <TableCell className={outstanding > 0 ? 'text-red-600 font-semibold' : 'text-green-600'}>
                        {order.currency} {outstanding.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </TableCell>
                      <TableCell>
                        {order.due_date ? (
                          <span className={overdue ? 'text-red-600 font-semibold' : ''}>
                            {new Date(order.due_date).toLocaleDateString()}
                            {overdue && ' (Overdue)'}
                          </span>
                        ) : (
                          '-'
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleEditOrder(order)}
                          title="Edit order"
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Edit Order</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Order Number *</Label>
              <Input
                value={formData.order_number}
                onChange={(e) => setFormData({ ...formData, order_number: e.target.value })}
                placeholder="ORD-001"
              />
            </div>

            <div className="space-y-2">
              <Label>Order Date *</Label>
              <Input
                type="date"
                value={formData.ordered_at}
                onChange={(e) => setFormData({ ...formData, ordered_at: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label>Status</Label>
              <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="PENDING">Pending</SelectItem>
                  <SelectItem value="PAID">Paid</SelectItem>
                  <SelectItem value="PARTIALLY_PAID">Partially Paid</SelectItem>
                  <SelectItem value="OVERDUE">Overdue</SelectItem>
                  <SelectItem value="CANCELLED">Cancelled</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-xs text-gray-500">
                Status auto-updates based on payment amount
              </p>
            </div>

            <div className="space-y-2">
              <Label>Currency</Label>
              <Select value={formData.currency} onValueChange={(value) => setFormData({ ...formData, currency: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="USD">USD</SelectItem>
                  <SelectItem value="EUR">EUR</SelectItem>
                  <SelectItem value="GBP">GBP</SelectItem>
                  <SelectItem value="JPY">JPY</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Total Amount *</Label>
              <Input
                type="number"
                step="0.01"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                placeholder="0.00"
              />
            </div>

            <div className="space-y-2">
              <Label>Paid Amount</Label>
              <Input
                type="number"
                step="0.01"
                value={formData.paid_amount}
                onChange={(e) => setFormData({ ...formData, paid_amount: e.target.value })}
                placeholder="0.00"
              />
              {parseFloat(formData.amount) > 0 && parseFloat(formData.paid_amount) > 0 && (
                <p className="text-xs text-gray-500">
                  {((parseFloat(formData.paid_amount) / parseFloat(formData.amount)) * 100).toFixed(0)}% paid
                </p>
              )}
            </div>

            <div className="space-y-2">
              <Label>Due Date</Label>
              <Input
                type="date"
                value={formData.due_date}
                onChange={(e) => setFormData({ ...formData, due_date: e.target.value })}
              />
            </div>

            <div className="space-y-2 col-span-2">
              <Label>Notes</Label>
              <Textarea
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                placeholder="Additional notes..."
                rows={3}
              />
            </div>
          </div>

          <div className="flex justify-end space-x-3 mt-4">
            <Button variant="outline" onClick={() => setShowEditDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleUpdateOrder}>Update Order</Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={showOrderDialog} onOpenChange={setShowOrderDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Create New Order</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Order Number *</Label>
              <Input
                value={formData.order_number}
                onChange={(e) => setFormData({ ...formData, order_number: e.target.value })}
                placeholder="ORD-001"
              />
            </div>

            <div className="space-y-2">
              <Label>Order Date *</Label>
              <Input
                type="date"
                value={formData.ordered_at}
                onChange={(e) => setFormData({ ...formData, ordered_at: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label>Status</Label>
              <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="PENDING">Pending</SelectItem>
                  <SelectItem value="PAID">Paid</SelectItem>
                  <SelectItem value="PARTIALLY_PAID">Partially Paid</SelectItem>
                  <SelectItem value="OVERDUE">Overdue</SelectItem>
                  <SelectItem value="CANCELLED">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Currency</Label>
              <Select value={formData.currency} onValueChange={(value) => setFormData({ ...formData, currency: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="USD">USD</SelectItem>
                  <SelectItem value="EUR">EUR</SelectItem>
                  <SelectItem value="GBP">GBP</SelectItem>
                  <SelectItem value="JPY">JPY</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Amount *</Label>
              <Input
                type="number"
                step="0.01"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                placeholder="0.00"
              />
            </div>

            <div className="space-y-2">
              <Label>Paid Amount</Label>
              <Input
                type="number"
                step="0.01"
                value={formData.paid_amount}
                onChange={(e) => setFormData({ ...formData, paid_amount: e.target.value })}
                placeholder="0.00"
              />
            </div>

            <div className="space-y-2">
              <Label>Due Date</Label>
              <Input
                type="date"
                value={formData.due_date}
                onChange={(e) => setFormData({ ...formData, due_date: e.target.value })}
              />
            </div>

            <div className="space-y-2 col-span-2">
              <Label>Notes</Label>
              <Textarea
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                placeholder="Additional notes..."
                rows={3}
              />
            </div>
          </div>

          <div className="flex justify-end space-x-3 mt-4">
            <Button variant="outline" onClick={() => setShowOrderDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleCreateOrder}>Create Order</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
