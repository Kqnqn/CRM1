'use client';

import { useEffect, useState } from 'react';
import { supabase, Activity, Note, AuditLog } from '@/lib/supabase/client';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Calendar, CheckSquare, FileText, History, Edit, Trash2, Check } from 'lucide-react';
import { format } from 'date-fns';
import { useToast } from '@/hooks/use-toast';

interface ActivityTimelineProps {
  relatedToType: string;
  relatedToId: string;
}

export function ActivityTimeline({ relatedToType, relatedToId }: ActivityTimelineProps) {
  const [activities, setActivities] = useState<Activity[]>([]);
  const [notes, setNotes] = useState<Note[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [newNote, setNewNote] = useState('');
  const [loading, setLoading] = useState(true);
  const [editingActivity, setEditingActivity] = useState<Activity | null>(null);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [editFormData, setEditFormData] = useState({
    subject: '',
    description: '',
    status: 'NOT_STARTED',
    priority: 'MEDIUM',
    due_date: '',
    start_time: '',
    end_time: '',
    location: '',
  });
  const { toast } = useToast();

  const fetchTimeline = async () => {
    setLoading(true);
    const [activitiesRes, notesRes, auditRes] = await Promise.all([
      supabase
        .from('activities')
        .select('*, owner:profiles!activities_owner_id_fkey(*)')
        .eq('related_to_type', relatedToType)
        .eq('related_to_id', relatedToId)
        .order('created_at', { ascending: false }),
      supabase
        .from('notes')
        .select('*, creator:profiles!notes_created_by_fkey(*)')
        .eq('related_to_type', relatedToType)
        .eq('related_to_id', relatedToId)
        .order('created_at', { ascending: false }),
      supabase
        .from('audit_log')
        .select('*, user:profiles!audit_log_user_id_fkey(*)')
        .eq('entity_type', relatedToType)
        .eq('entity_id', relatedToId)
        .order('created_at', { ascending: false })
        .limit(20),
    ]);

    if (activitiesRes.data) setActivities(activitiesRes.data);
    if (notesRes.data) setNotes(notesRes.data);
    if (auditRes.data) setAuditLogs(auditRes.data);
    setLoading(false);
  };

  useEffect(() => {
    fetchTimeline();
  }, [relatedToType, relatedToId]);

  const handleAddNote = async () => {
    if (!newNote.trim()) return;

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    await supabase.from('notes').insert({
      content: newNote,
      related_to_type: relatedToType,
      related_to_id: relatedToId,
      created_by: user.id,
    });

    setNewNote('');
    fetchTimeline();
  };

  const handleEditActivity = (activity: Activity) => {
    setEditingActivity(activity);
    setEditFormData({
      subject: activity.subject || '',
      description: activity.description || '',
      status: activity.status || 'NOT_STARTED',
      priority: activity.priority || 'MEDIUM',
      due_date: activity.due_date ? new Date(activity.due_date).toISOString().slice(0, 16) : '',
      start_time: activity.start_time ? new Date(activity.start_time).toISOString().slice(0, 16) : '',
      end_time: activity.end_time ? new Date(activity.end_time).toISOString().slice(0, 16) : '',
      location: activity.location || '',
    });
    setShowEditDialog(true);
  };

  const handleUpdateActivity = async () => {
    if (!editingActivity) return;

    const activityType = editingActivity.type;
    const updateData: any = {
      subject: editFormData.subject,
      description: editFormData.description,
    };

    if (activityType === 'TASK' || activityType === 'CALL' || activityType === 'EMAIL' || activityType === 'NOTE' || activityType === 'MEETING') {
      updateData.status = editFormData.status;
      updateData.priority = editFormData.priority;
      updateData.due_date = editFormData.due_date || null;
    }

    if (activityType === 'EVENT' || activityType === 'MEETING') {
      updateData.start_time = editFormData.start_time || null;
      updateData.end_time = editFormData.end_time || null;
      updateData.location = editFormData.location || null;
    }

    const { error } = await supabase
      .from('activities')
      .update(updateData)
      .eq('id', editingActivity.id);

    if (!error) {
      toast({
        title: 'Activity updated',
        description: 'Activity has been updated successfully',
      });
      setShowEditDialog(false);
      setEditingActivity(null);
      fetchTimeline();
    } else {
      toast({
        title: 'Update failed',
        description: error.message,
        variant: 'destructive',
      });
    }
  };

  const handleDeleteActivity = async (activityId: string) => {
    if (!confirm('Are you sure you want to delete this activity?')) return;

    const { error } = await supabase
      .from('activities')
      .delete()
      .eq('id', activityId);

    if (!error) {
      toast({
        title: 'Activity deleted',
        description: 'Activity has been deleted successfully',
      });
      fetchTimeline();
    }
  };

  const handleMarkComplete = async (activityId: string) => {
    const { error } = await supabase
      .from('activities')
      .update({ completed: true, status: 'COMPLETED' })
      .eq('id', activityId);

    if (!error) {
      toast({
        title: 'Task completed',
        description: 'Task has been marked as completed',
      });
      fetchTimeline();
    }
  };

  const combinedTimeline = [
    ...activities.map((a) => ({ ...a, itemType: 'activity' })),
    ...notes.map((n) => ({ ...n, itemType: 'note' })),
    ...auditLogs.map((l) => ({ ...l, itemType: 'audit' })),
  ].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

  if (loading) {
    return <div className="text-center py-4">Loading timeline...</div>;
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardContent className="p-4">
          <Textarea
            placeholder="Add a note..."
            value={newNote}
            onChange={(e) => setNewNote(e.target.value)}
            className="mb-2"
          />
          <Button onClick={handleAddNote} size="sm">
            Add Note
          </Button>
        </CardContent>
      </Card>

      <div className="space-y-3">
        {combinedTimeline.map((item: any, index) => (
          <Card key={index}>
            <CardContent className="p-4">
              <div className="flex items-start space-x-3">
                <div className="flex-shrink-0">
                  {item.itemType === 'activity' && item.type === 'TASK' && (
                    <CheckSquare className="h-5 w-5 text-blue-600" />
                  )}
                  {item.itemType === 'activity' && item.type === 'EVENT' && (
                    <Calendar className="h-5 w-5 text-green-600" />
                  )}
                  {item.itemType === 'note' && (
                    <FileText className="h-5 w-5 text-purple-600" />
                  )}
                  {item.itemType === 'audit' && (
                    <History className="h-5 w-5 text-gray-600" />
                  )}
                </div>
                <div className="flex-1">
                  {item.itemType === 'activity' && (
                    <>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <span className="font-medium">{item.subject}</span>
                          <Badge variant="outline">{item.status}</Badge>
                          {item.completed && (
                            <Badge className="bg-green-100 text-green-800">Completed</Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-2">
                          {!item.completed && (item.type === 'TASK' || item.type === 'CALL' || item.type === 'EMAIL') && (
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => handleMarkComplete(item.id)}
                              title="Mark as complete"
                            >
                              <Check className="h-4 w-4 text-green-600" />
                            </Button>
                          )}
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleEditActivity(item)}
                            title="Edit"
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleDeleteActivity(item.id)}
                            title="Delete"
                          >
                            <Trash2 className="h-4 w-4 text-red-600" />
                          </Button>
                        </div>
                      </div>
                      {item.description && (
                        <p className="text-sm text-gray-600 mt-1">{item.description}</p>
                      )}
                      {item.due_date && (
                        <p className="text-xs text-gray-600 mt-1">
                          Due: {format(new Date(item.due_date), 'MMM d, yyyy h:mm a')}
                        </p>
                      )}
                      <p className="text-xs text-gray-500 mt-1">
                        {item.owner?.full_name} • {format(new Date(item.created_at), 'MMM d, yyyy h:mm a')}
                      </p>
                    </>
                  )}
                  {item.itemType === 'note' && (
                    <>
                      {item.title && <p className="font-medium">{item.title}</p>}
                      <p className="text-sm text-gray-700">{item.content}</p>
                      <p className="text-xs text-gray-500 mt-1">
                        {item.creator?.full_name} • {format(new Date(item.created_at), 'MMM d, yyyy h:mm a')}
                      </p>
                    </>
                  )}
                  {item.itemType === 'audit' && (
                    <>
                      <p className="text-sm">
                        <span className="font-medium">{item.action}</span>
                        {item.field_name && ` - ${item.field_name}`}
                      </p>
                      {item.old_value && item.new_value && (
                        <p className="text-xs text-gray-600">
                          Changed from "{item.old_value}" to "{item.new_value}"
                        </p>
                      )}
                      <p className="text-xs text-gray-500 mt-1">
                        {item.user?.full_name} • {format(new Date(item.created_at), 'MMM d, yyyy h:mm a')}
                      </p>
                    </>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {combinedTimeline.length === 0 && (
        <div className="text-center py-8 text-gray-500">
          No activity yet
        </div>
      )}

      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Edit Activity</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Subject</Label>
              <Input
                value={editFormData.subject}
                onChange={(e) => setEditFormData({ ...editFormData, subject: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label>Description</Label>
              <Textarea
                value={editFormData.description}
                onChange={(e) => setEditFormData({ ...editFormData, description: e.target.value })}
                rows={3}
              />
            </div>

            {editingActivity && (editingActivity.type === 'TASK' || editingActivity.type === 'CALL' || editingActivity.type === 'EMAIL' || editingActivity.type === 'NOTE') && (
              <>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Status</Label>
                    <Select
                      value={editFormData.status}
                      onValueChange={(value) => setEditFormData({ ...editFormData, status: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="NOT_STARTED">Not Started</SelectItem>
                        <SelectItem value="IN_PROGRESS">In Progress</SelectItem>
                        <SelectItem value="COMPLETED">Completed</SelectItem>
                        <SelectItem value="CANCELLED">Cancelled</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Priority</Label>
                    <Select
                      value={editFormData.priority}
                      onValueChange={(value) => setEditFormData({ ...editFormData, priority: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="LOW">Low</SelectItem>
                        <SelectItem value="MEDIUM">Medium</SelectItem>
                        <SelectItem value="HIGH">High</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Due Date</Label>
                  <Input
                    type="datetime-local"
                    value={editFormData.due_date}
                    onChange={(e) => setEditFormData({ ...editFormData, due_date: e.target.value })}
                  />
                </div>
              </>
            )}

            {editingActivity && (editingActivity.type === 'EVENT' || editingActivity.type === 'MEETING') && (
              <>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Start Time</Label>
                    <Input
                      type="datetime-local"
                      value={editFormData.start_time}
                      onChange={(e) => setEditFormData({ ...editFormData, start_time: e.target.value })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>End Time</Label>
                    <Input
                      type="datetime-local"
                      value={editFormData.end_time}
                      onChange={(e) => setEditFormData({ ...editFormData, end_time: e.target.value })}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Location</Label>
                  <Input
                    value={editFormData.location}
                    onChange={(e) => setEditFormData({ ...editFormData, location: e.target.value })}
                    placeholder="e.g., Conference Room A, Zoom"
                  />
                </div>
              </>
            )}

            <div className="flex justify-end space-x-3 pt-4">
              <Button
                variant="outline"
                onClick={() => setShowEditDialog(false)}
              >
                Cancel
              </Button>
              <Button onClick={handleUpdateActivity}>
                Update Activity
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
